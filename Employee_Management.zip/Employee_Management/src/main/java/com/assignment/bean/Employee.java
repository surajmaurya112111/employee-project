package com.assignment.bean;

import java.time.LocalDate;

public class Employee {
	private Integer employeeId;
	private String name;
	private String address;
	private Byte gender;
	private Double salary;
	private LocalDate birthdate;
	
	public Employee() {
		super();
	}
	
	

	public Employee(String name, String address, Byte gender, Double salary, LocalDate birthdate) {
		super();
		this.name = name;
		this.address = address;
		this.gender = gender;
		this.salary = salary;
		this.birthdate = birthdate;
	}



	public Employee(Integer employeeId, String name, String address, Byte gender, Double salary, LocalDate birthdate) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.address = address;
		this.gender = gender;
		this.salary = salary;
		this.birthdate = birthdate;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Byte getGender() {
		return gender;
	}

	public void setGender(Byte gender) {
		this.gender = gender;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public LocalDate getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}

	@Override
	public String toString() {
		return "employeeId=" + employeeId + ", name=" + name + ", address=" + address + ", gender=" + gender
				+ ", salary=" + salary + ", birthdate=" + birthdate;
	}
	
	
	

}
