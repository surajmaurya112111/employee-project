package com.assignment.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.assignment.bean.Employee;
import com.assignment.dao.EmployeeDao;
import com.assignment.dao.EmployeeDaoImpl;

@WebServlet("/NavePageEmployee")
public class NavePageEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeDao employeeDao = new EmployeeDaoImpl(); 

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Integer id = Integer.parseInt(request.getParameter("id").trim());
			Integer max = 5;
			Integer last = id+5;
			System.out.println(id);
			
			List<Employee> showEmployee = employeeDao.showEmployee(id, last);
			if(!showEmployee.equals(null)) {
				request.setAttribute("showEmployee", showEmployee);
				
				request.getRequestDispatcher("nav-view-employee.jsp").forward(request, response);
			
			}else {
				response.getWriter().println("<h1>No record!!</h1>");
				request.getRequestDispatcher("NavePageEmployee?id=0").include(request, response);
			
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			response.getWriter().println("<h1>No record!!</h1>");
			request.getRequestDispatcher("add-emp.jsp").include(request, response);
		
		}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
