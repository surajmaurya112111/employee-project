package com.assignment.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.assignment.dao.EmployeeDao;
import com.assignment.dao.EmployeeDaoImpl;

@WebServlet("/DeleteEmployee")
public class DeleteEmployee extends HttpServlet {
	private EmployeeDao employeeDao = new EmployeeDaoImpl(); 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Integer id = Integer.parseInt(request.getParameter("id"));

			Integer deleteEmploee = employeeDao.deleteEmploee(id);
			if(!deleteEmploee.equals(null)) {
				request.getRequestDispatcher("ShowEmployee").forward(request, response);
			}else {
				response.getWriter().println("<h1>Something went wrong!!</h1>");
				request.getRequestDispatcher("ShowEmployee").include(request, response);
			}

		}catch(Exception e) {
			e.printStackTrace();
		}


	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
