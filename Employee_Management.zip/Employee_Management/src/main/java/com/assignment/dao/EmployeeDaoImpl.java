package com.assignment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.assignment.bean.Employee;

public class EmployeeDaoImpl implements EmployeeDao {


	@Override
	public List<Employee> showEmployee() {
		Connection connection = null;
		String query = "select * from employee";

		connection = JdbcConnection.getConnection();
		try {
			Statement statement = connection.createStatement();
			ResultSet executeQuery = statement.executeQuery(query);
			List<Employee> employeeList = new ArrayList();
			while(executeQuery.next()) {
			Employee employee= new Employee();
			getEmployee(executeQuery, employee);
			employeeList.add(employee);
			}
			return employeeList;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	private void getEmployee(ResultSet rs, Employee employee) {
		 
		try {
			employee.setEmployeeId(rs.getInt("id"));
			employee.setName(rs.getString("name"));
			employee.setAddress(rs.getString("address"));
			employee.setGender(Byte.valueOf((byte) rs.getInt("gender")));
			employee.setSalary(rs.getDouble("salary"));
			employee.setBirthdate(rs.getDate("birthdate").toLocalDate());

			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Integer deleteEmploee(Integer id) {
		Connection connection = null;
		String query = "delete from employee where id = ?";

		connection = JdbcConnection.getConnection();
		try {
			PreparedStatement prepareStatement = connection.prepareStatement(query);
			prepareStatement.setInt(1, id);
			int executeUpdate = prepareStatement.executeUpdate();
			if(executeUpdate>0) {
				return 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public Integer addEmployee(Employee employee) {
		Connection connection = null;
		String query = "insert into employee(name, address, gender, salary, birthdate) values (?,?,?,?,?)";

		connection = JdbcConnection.getConnection();
		try {
			PreparedStatement prepareStatement = connection.prepareStatement(query);
			System.out.println("DAO  "+employee);
//			prepareStatement.setInt(1, employee.getEmployeeId());
			prepareStatement.setString(1, employee.getName());
			prepareStatement.setString(2, employee.getAddress());
			prepareStatement.setInt(3, employee.getGender());
			prepareStatement.setDouble(4, employee.getSalary());
			prepareStatement.setDate(5, java.sql.Date.valueOf(employee.getBirthdate()));
		
			int executeUpdate = prepareStatement.executeUpdate();
			if(executeUpdate>0)
				return 1;
			else 
				return null;
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Employee> showEmployee(Integer start, Integer last) {
		Connection connection = null;
		String query = "select * from employee where id between "+start+" and "+last;

		connection = JdbcConnection.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet executeQuery = statement.executeQuery();
			List<Employee> employeeList = new ArrayList();
			while(executeQuery.next()) {
			Employee employee= new Employee();
			getEmployee(executeQuery, employee);
			employeeList.add(employee);
			}
			return employeeList;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

}
