package com.assignment.dao;

import java.util.List;

import com.assignment.bean.Employee;

public interface EmployeeDao {
	List<Employee> showEmployee();
	List<Employee> showEmployee(Integer start, Integer last);
	Integer deleteEmploee(Integer id);
	Integer addEmployee(Employee employee);

}
