function formValidation()
{
	var uname = document.registration.name;
	{
	if(allLetter(uname))
		{
		}
		}
		return false;
}





//Name Validation
function allLetter(uname){
    var regName = /[a-zA-Z]+ [a-zA-Z]+$/;
   
if(uname.value.match(letters))
{
return true;
}
else
{
alert('Username must have alphabet characters only');
uname.focus();
return false;
}
}



// Mobile Number Validation
 var salary= document.getElementById("salary");

 var salaryValidation = function(){

   salaryValue=salary.value.trim(); 
   validSalary=/^[0-9]*$/;
   salaryErr=document.getElementById('salaryerr');

   if(salaryValue=="")
   {
    salaryErr.innerHTML="Salary is required";

   }else if(!validSalary.test(salaryValue)){
     salaryErr.innerHTML="Salary must be a number";
   }
   else{
     salaryErr.innerHTML="";
     return true;
   }

 }
mobileNumber.oninput=function(){

   salaryValidation();
}